TIP CALCULATOR (JavaFX + FXML)

Files:
- TipCalculatorApp.java       Main JavaFX application
- TipCalculatorController.java Controller for calculate/reset actions
- tip_calculator.fxml         User interface layout

Important:
Keep all three files in the same source/resource folder for this simple, non-modular setup.
The FXML file uses fx:controller="TipCalculatorController".

Compile and run:
You need a JDK and JavaFX SDK installed. Replace /path/to/javafx/lib with your JavaFX SDK lib directory.

From the folder containing the three files:

javac --module-path "/path/to/javafx/lib" --add-modules javafx.controls,javafx.fxml TipCalculatorApp.java TipCalculatorController.java

java --module-path "/path/to/javafx/lib" --add-modules javafx.controls,javafx.fxml TipCalculatorApp

Example:
Bill Amount = 50
Tip Percentage = 15
Click Calculate Tip -> Tip Amount: $7.50

Non-numeric input shows an error. Reset clears both input fields and result/error labels.
