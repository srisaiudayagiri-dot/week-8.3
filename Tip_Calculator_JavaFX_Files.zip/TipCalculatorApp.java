import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class TipCalculatorApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        URL fxmlUrl = getClass().getResource("tip_calculator.fxml");
        if (fxmlUrl == null) {
            throw new IllegalStateException(
                    "Could not find tip_calculator.fxml. Place it beside TipCalculatorApp.class.");
        }

        Parent root = FXMLLoader.load(fxmlUrl);
        primaryStage.setTitle("Tip Calculator");
        primaryStage.setScene(new Scene(root));
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
